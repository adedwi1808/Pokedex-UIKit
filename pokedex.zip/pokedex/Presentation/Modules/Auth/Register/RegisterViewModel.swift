//
//  RegisterViewModel.swift
//  pokedex
//
//  Created by Ade Dwi Prayitno on 04/11/25.
//

import Foundation
import RxSwift
import RxCocoa

final class RegisterViewModel {
    let username = BehaviorRelay<String>(value: "")
    let password = BehaviorRelay<String>(value: "")
    let confirmPassword = BehaviorRelay<String>(value: "")
    let registerTap = PublishRelay<Void>()
    
    let isRegisterEnabled = BehaviorRelay<Bool>(value: false)
    let registerResult = PublishRelay<Bool>()
    
    private let disposeBag = DisposeBag()
    
    init() {
        setupBindings()
    }
    
    private func setupBindings() {
        Observable
            .combineLatest(username, password, confirmPassword)
            .map { username, password, confirmPassword in
                return !username.isEmpty && !password.isEmpty && !confirmPassword.isEmpty
            }
            .distinctUntilChanged()
            .bind(to: isRegisterEnabled)
            .disposed(by: disposeBag)
        
        registerTap
            .withLatestFrom(Observable.combineLatest(username, password, confirmPassword))
            .map { username, password, confirmPassword in
                if username.lowercased() == "admin" || password != confirmPassword {
                    return false
                } else {
                    return true
                }
            }
            .bind(to: registerResult)
            .disposed(by: disposeBag)
    }
}
