//
//  LoginViewModel.swift
//  pokedex
//
//  Created by Ade Dwi Prayitno on 04/11/25.
//

import Foundation
import RxSwift
import RxCocoa

final class LoginViewModel {
    let username = BehaviorRelay<String>(value: "")
    let password = BehaviorRelay<String>(value: "")
    let loginTap = PublishRelay<Void>()
    
    let isLoginEnabled = BehaviorRelay<Bool>(value: false)
    let loginResult = PublishRelay<Bool>()
    
    private let disposeBag = DisposeBag()
    
    init() {
        setupBindings()
    }
    
    private func setupBindings() {
        Observable
            .combineLatest(username, password)
            .map { !$0.isEmpty && !$1.isEmpty }
            .distinctUntilChanged()
            .bind(to: isLoginEnabled)
            .disposed(by: disposeBag)
        
        loginTap
            .withLatestFrom(Observable.combineLatest(username, password))
            .map { username, password in
                if username == "admin" && password == "1234" {
                    UserDefaults.isLoggedIn = true
                    return true
                } else {
                    return false
                }
            }
            .bind(to: loginResult)
            .disposed(by: disposeBag)
    }
}

