//
//  HomeView.swift
//  pokedex
//
//  Created by Ade Dwi Prayitno on 04/11/25.
//

import UIKit
import SnapKit

final class HomeView: UIView {

    let tableView = UITableView()
    let searchController = UISearchController(searchResultsController: nil)

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }

    private func setupUI() {
        backgroundColor = .systemBackground

        searchController.searchBar.placeholder = "Cari Nama Pokemon"
        searchController.obscuresBackgroundDuringPresentation = false

        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "PokemonCell")
        addSubview(tableView)

        tableView.snp.makeConstraints {
            $0.edges.equalToSuperview()
        }
    }
}
