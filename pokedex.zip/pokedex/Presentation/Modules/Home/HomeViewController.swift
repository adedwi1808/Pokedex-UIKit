//
//  HomeViewController.swift
//  pokedex
//
//  Created by Ade Dwi Prayitno on 04/11/25.
//

import UIKit
import RxSwift
import RxCocoa
import MBProgressHUD
import XLPagerTabStrip

final class HomeViewController: UIViewController, IndicatorInfoProvider {
    
    private let contentView = HomeView()
    private let viewModel: HomeViewModel
    private let disposeBag = DisposeBag()
    
    init(viewModel: HomeViewModel) {
        self.viewModel = viewModel
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) { fatalError("init(coder:) has not been implemented") }
    
    override func loadView() {
        view = contentView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
        bindViewModel()
        viewModel.viewDidLoad.accept(())
    }
    
    private func setupNavigation() {
        navigationItem.searchController = contentView.searchController
    }
    
    private func bindViewModel() {
        viewModel.pokemonList
            .bind(to: contentView.tableView.rx.items(
                cellIdentifier: "PokemonCell",
                cellType: UITableViewCell.self)
            ) { (row, pokemon, cell) in
                cell.textLabel?.text = pokemon.name.capitalized
                cell.accessoryType = .disclosureIndicator
            }
            .disposed(by: disposeBag)
        
        contentView.tableView.rx.modelSelected(Pokemon.self)
            .bind(to: viewModel.itemSelected)
            .disposed(by: disposeBag)
        
        contentView.tableView.rx.willDisplayCell
            .subscribe(onNext: { [weak self] (_, indexPath) in
                guard let self = self else { return }
                let lastRow = self.contentView.tableView.numberOfRows(inSection: 0) - 1
                if indexPath.row == lastRow {
                    self.viewModel.loadNextPage.accept(())
                }
            })
            .disposed(by: disposeBag)
        
        contentView.searchController.searchBar.rx.searchButtonClicked
            .map { self.contentView.searchController.searchBar.text ?? "" }
            .bind(to: viewModel.searchTapped)
            .disposed(by: disposeBag)
        
        viewModel.isLoading.asDriver()
            .drive(onNext: { [weak self] isLoading in
                guard let self = self else { return }
                if isLoading {
                    MBProgressHUD.showAdded(to: self.view, animated: true)
                } else {
                    MBProgressHUD.hide(for: self.view, animated: true)
                }
            })
            .disposed(by: disposeBag)
        
        viewModel.showError.asDriver(onErrorJustReturn: "Error")
            .drive(onNext: { [weak self] message in
                self?.showErrorAlert(message: message)
            })
            .disposed(by: disposeBag)
    }
    
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(title: "Home")
    }
}
