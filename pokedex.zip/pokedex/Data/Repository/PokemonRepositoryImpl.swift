//
//  PokemonRepositoryImpl.swift
//  pokedex
//
//  Created by Ade Dwi Prayitno on 04/11/25.
//


import Foundation
import RxSwift

final class PokemonRepositoryImpl: PokemonRepositoryProtocol {
    
    private let apiService: APIService
    
    init(apiService: APIService) {
        self.apiService = apiService
    }
    
    func getPokemonList(offset: Int, limit: Int) -> Observable<[Pokemon]> {
        return apiService.fetchPokemonList(offset: offset, limit: limit)
            .map { $0.results }
    }
    
    func getPokemonDetail(name: String) -> Observable<PokemonDetail> {
        return apiService.fetchPokemonDetail(name: name)
    }
}
